package positionalStructures;

public interface Position<E> {
	E getElement(); 
	void setElement(E e); 
}
