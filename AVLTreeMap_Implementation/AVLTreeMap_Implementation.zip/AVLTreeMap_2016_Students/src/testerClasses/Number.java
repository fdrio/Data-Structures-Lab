package testerClasses;


public class Number {
	private int value; 
	private String numeral; 
	public Number(int value, String numeral) { 
		this.value = value; 
		this.numeral = numeral; 
	}
	public int getValue() {
		return value;
	}
	public String getNumeral() { 
		return numeral; 
	}
}
